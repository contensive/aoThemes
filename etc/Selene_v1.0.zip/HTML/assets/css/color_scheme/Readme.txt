By default, green.css is already integrated on layout.css (you don't need to include again)
If you want a different color, add AFTER layout.css:

<link href="assets/css/color_scheme/red.css" rel="stylesheet" type="text/css" />