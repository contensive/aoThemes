Download winLess from going to http://winless.org/ (for windows) and mac users can go to (http://incident57.com/less/) - they are both small apps/programs. 

Once installed load up and drop in the less folder to the 'Less Files' zone. Deselect all selected less files and only select "production.less".

Hit compile and it should automatically create a minified CSS file to your css directory called "production.css"!

You can also use Prepros, another alternative LESS compiler with greater CSS compression! 

Download link: http://alphapixels.com/prepros/